<?php
$string['pluginname'] = 'ScholarWatch';
$string['scholarwatch'] = 'ScholarWatch';
