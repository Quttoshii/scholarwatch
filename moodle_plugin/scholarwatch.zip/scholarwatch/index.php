<?php
require_once(__DIR__ . '/../../config.php');
require_login();

$fullname = fullname($USER);
$email = $USER->email;
$userid = $USER->id;

$context = context_system::instance();
$role = null;

if (is_siteadmin($USER)) {
    $role = 'admin';
} else {
    $roles = get_user_roles($context, $USER->id);

    foreach ($roles as $r) {
        if ($r->shortname === 'editingteacher' || $r->shortname === 'teacher') {
            $role = 'teacher';
            break;
        } else if ($r->shortname === 'student') {
            $role = 'student';
            break;
        }
    }
}

if ($role === null) {
    print_error('Access denied: Only students and teachers can access ScholarWatch.');
    exit;
}

$react_url = 'http://localhost:3000'; // Replace with your React app URL

$origin = new moodle_url('/'); // Or a specific dashboard/course page if preferred
$return_url = urlencode($origin->out(false));

$redirect_url = $react_url . "?userid=$userid&fullname=" . urlencode($fullname) . "&email=" . urlencode($email) . "&role=$role&returnto=$return_url";
redirect($redirect_url);
