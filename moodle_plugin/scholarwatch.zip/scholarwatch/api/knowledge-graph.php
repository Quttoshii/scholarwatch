<?php

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:3000");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    http_response_code(200);
    exit;
}

// Set CORS headers for all requests
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

require_once(__DIR__ . '/../../../config.php');
require_login();

$action = optional_param('action', 'get', PARAM_ALPHANUMEXT);
$courseid = optional_param('courseId', null, PARAM_INT);
$studentid = optional_param('studentId', null, PARAM_INT);
global $DB;

try {
    switch ($action) {
        case 'get':
            get_knowledge_graph($courseid, $studentid); // ✅ Fixed function call
            break;
        case 'updateNodePosition':
            update_node_position();
            break;
        case 'addNode':
            add_node();
            break;
        case 'updateNode':
            update_node();
            break;
        case 'deleteNode':
            delete_node();
            break;
        case 'addEdge':
            add_edge();
            break;
        case 'deleteEdge':
            delete_edge();
            break;
        case 'updateNodeStatus':
            update_node_status($studentid);
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

// -- FUNCTIONS --

function get_knowledge_graph($courseId, $studentId) { // ✅ Fixed function name and added parameters
    global $DB;

    if (!$courseId) {
        echo json_encode(['success' => false, 'message' => 'Course ID is required']);
        return;
    }

    try {
        // Check if graph exists
        $graph = $DB->get_record('local_scholarwatch_knowledgegraph', ['courseid' => $courseId]);

        // If not found, create one
        if (!$graph) {
            $graph = new stdClass();
            $graph->courseid = $courseId;
            $graph->name = 'Course Knowledge Graph';
            $graph->description = 'Knowledge graph for course';
            $graph->createdat = time();
            $graph->id = $DB->insert_record('local_scholarwatch_knowledgegraph', $graph);
        }

        $graphId = $graph->id;

        // Fetch nodes
        $nodes = $DB->get_records('local_scholarwatch_knowledgenode', ['graphid' => $graphId]);
        $formattedNodes = [];

        foreach ($nodes as $node) {
            $status = 'LOCKED';
            if ($studentId) {
                $statusRecord = $DB->get_record('local_scholarwatch_studentlecturestatus', [
                    'studentid' => $studentId,
                    'nodeid' => $node->id
                ]);
                $status = $statusRecord ? $statusRecord->status : 'LOCKED'; // ✅ Fixed null coalescing
            } else {
                $status = $node->status ?? 'LOCKED';
            }

            $formattedNodes[] = [
                'id' => (string)$node->id,
                'type' => $node->type,
                'position' => [
                    'x' => (float)$node->positionx,
                    'y' => (float)$node->positiony,
                ],
                'data' => [
                    'label' => $node->name,
                    'description' => $node->description,
                    'lectureId' => $node->lectureid,
                    'status' => $status
                ]
            ];
        }

        // Fetch edges
        $edges = $DB->get_records('local_scholarwatch_knowledgeedge', ['graphid' => $graphId]);
        $formattedEdges = [];

        foreach ($edges as $edge) {
            $formattedEdges[] = [
                'id' => (string)$edge->id,
                'source' => (string)$edge->sourcenodeid,
                'target' => (string)$edge->targetnodeid,
                'type' => $edge->type,
                'weight' => (float)$edge->weight
            ];
        }

        echo json_encode([
            'success' => true,
            'graphId' => $graphId,
            'nodes' => $formattedNodes,
            'edges' => $formattedEdges
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Error fetching graph: ' . $e->getMessage()
        ]);
    }
}

function update_node_position() {
    global $DB;
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['nodeId']) || !isset($data['x']) || !isset($data['y'])) {
        throw new moodle_exception('Missing fields');
    }

    $DB->update_record('local_scholarwatch_knowledgenode', (object)[
        'id' => $data['nodeId'],
        'positionx' => $data['x'],
        'positiony' => $data['y']
    ]);

    echo json_encode(['success' => true]);
}

function add_node() {
    global $DB;
    $data = json_decode(file_get_contents('php://input'), true);

    $node = (object)[
        'graphid' => $data['graphId'],
        'name' => $data['name'],
        'type' => $data['type'],
        'description' => $data['description'] ?? '',
        'positionx' => $data['x'] ?? 0,
        'positiony' => $data['y'] ?? 0,
        'lectureid' => $data['lectureId'] ?? null,
        'status' => $data['status'] ?? 'LOCKED'
    ];

    $node->id = $DB->insert_record('local_scholarwatch_knowledgenode', $node);
    echo json_encode(['success' => true, 'nodeId' => $node->id]);
}

function update_node() {
    global $DB;
    $data = json_decode(file_get_contents('php://input'), true);

    $node = $DB->get_record('local_scholarwatch_knowledgenode', ['id' => $data['nodeId']], '*', MUST_EXIST);
    $node->name = $data['name'];
    $node->description = $data['description'] ?? '';
    $node->type = $data['type'];
    $node->lectureid = $data['lectureId'] ?? null;
    if (isset($data['status'])) {
        $node->status = $data['status'];
    }

    $DB->update_record('local_scholarwatch_knowledgenode', $node);
    echo json_encode(['success' => true]);
}

function delete_node() {
    global $DB;
    $data = json_decode(file_get_contents('php://input'), true);
    $nodeid = $data['nodeId'] ?? null;

    if (!$nodeid) {
        throw new moodle_exception('Node ID is required');
    }

    $DB->delete_records('local_scholarwatch_knowledgeedge', ['sourcenodeid' => $nodeid]);
    $DB->delete_records('local_scholarwatch_knowledgeedge', ['targetnodeid' => $nodeid]);
    $DB->delete_records('local_scholarwatch_studentlecturestatus', ['nodeid' => $nodeid]);
    $DB->delete_records('local_scholarwatch_knowledgenode', ['id' => $nodeid]);

    echo json_encode(['success' => true]);
}

function add_edge() {
    global $DB;
    $data = json_decode(file_get_contents('php://input'), true);

    $edge = (object)[
        'graphid' => $data['graphId'],
        'sourcenodeid' => $data['sourceId'],
        'targetnodeid' => $data['targetId'],
        'type' => $data['type'] ?? 'PREREQUISITE',
        'weight' => $data['weight'] ?? 1.0
    ];

    $edge->id = $DB->insert_record('local_scholarwatch_knowledgeedge', $edge);
    echo json_encode(['success' => true, 'edgeId' => $edge->id]);
}

function delete_edge() {
    global $DB;
    $data = json_decode(file_get_contents('php://input'), true);
    $edgeid = $data['edgeId'] ?? null;

    if (!$edgeid) {
        throw new moodle_exception('Edge ID is required');
    }

    $DB->delete_records('local_scholarwatch_knowledgeedge', ['id' => $edgeid]);
    echo json_encode(['success' => true]);
}

function update_node_status($studentid) {
    global $DB;
    $data = json_decode(file_get_contents('php://input'), true);
    $nodeid = $data['nodeId'] ?? null;
    $status = $data['status'] ?? null;

    if (!$nodeid || !$status) {
        throw new moodle_exception('Missing nodeId or status');
    }

    $valid = ['LOCKED', 'UNLOCKED', 'COMPLETED'];
    if (!in_array($status, $valid)) {
        throw new moodle_exception('Invalid status value');
    }

    if ($studentid) {
        $record = $DB->get_record('local_scholarwatch_studentlecturestatus', ['studentid' => $studentid, 'nodeid' => $nodeid]);
        if ($record) {
            $record->status = $status;
            $DB->update_record('local_scholarwatch_studentlecturestatus', $record);
        } else {
            $DB->insert_record('local_scholarwatch_studentlecturestatus', (object)[
                'studentid' => $studentid,
                'nodeid' => $nodeid,
                'status' => $status
            ]);
        }

        if ($status === 'COMPLETED') {
            // Unlock child nodes
            $children = $DB->get_records('local_scholarwatch_knowledgeedge', ['sourcenodeid' => $nodeid]);
            foreach ($children as $child) {
                $prereqs = $DB->get_records('local_scholarwatch_knowledgeedge', ['targetnodeid' => $child->targetnodeid]);
                $allcompleted = true;
                foreach ($prereqs as $p) {
                    $s = $DB->get_record('local_scholarwatch_studentlecturestatus', ['studentid' => $studentid, 'nodeid' => $p->sourcenodeid]);
                    if (!$s || $s->status !== 'COMPLETED') {
                        $allcompleted = false;
                        break;
                    }
                }
                if ($allcompleted) {
                    $existing = $DB->get_record('local_scholarwatch_studentlecturestatus', ['studentid' => $studentid, 'nodeid' => $child->targetnodeid]);
                    if (!$existing) {
                        $DB->insert_record('local_scholarwatch_studentlecturestatus', (object)[
                            'studentid' => $studentid,
                            'nodeid' => $child->targetnodeid,
                            'status' => 'UNLOCKED'
                        ]);
                    }
                }
            }
        }
    } else {
        $DB->update_record('local_scholarwatch_knowledgenode', (object)[
            'id' => $nodeid, 
            'status' => $status
        ]);
    }

    echo json_encode(['success' => true, 'status' => $status]);
}