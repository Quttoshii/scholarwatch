<?php
require_once(__DIR__ . '/../../../config.php');
require_login();

header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    global $DB;

    $response = [];

    // Fetch all courses with proper Moodle table names
    $courses = $DB->get_records('local_scholarwatch_course', null, '', 'id, name, teacherid');

    // Get total students globally
    $total_students = $DB->count_records_select('local_scholarwatch_user', "usertype = 'Student'");
    $response['all_students'] = $total_students;

    // Prepare response array
    $response['courses'] = [];

    foreach ($courses as $course) {
        $courseID = $course->id;

        // Total uploaded lectures for this course
        $total_lectures = $DB->count_records('local_scholarwatch_lecture', ['courseid' => $courseID]);

        // Invalidation count for quizzes in this course
        $sql = "SELECT COUNT(*) as invalidations 
                FROM {local_scholarwatch_quiz} q
                JOIN {local_scholarwatch_session} s ON q.sessionid = s.id
                WHERE s.courseid = :courseid AND q.is_invalid = 1";
        $invalidation_result = $DB->get_record_sql($sql, ['courseid' => $courseID]);
        $invalidation_count = $invalidation_result ? $invalidation_result->invalidations : 0;

        // Emotions & Attention
        $sql = "SELECT 
                    SUM(a.awaketime) as awake_time,
                    SUM(a.drowsytime) as drowsy_time,
                    SUM(a.focustime) as focused_time,
                    SUM(a.unfocustime) as unfocused_time
                FROM {local_scholarwatch_activity} a
                JOIN {local_scholarwatch_session} se ON a.sessionid = se.id
                WHERE se.courseid = :courseid";
        $activityData = $DB->get_record_sql($sql, ['courseid' => $courseID]);
        
        $emotions = [
            'awake_time' => $activityData && $activityData->awake_time ? (float)$activityData->awake_time : 0,
            'drowsy_time' => $activityData && $activityData->drowsy_time ? (float)$activityData->drowsy_time : 0,
        ];
        $attention = [
            'focused_time' => $activityData && $activityData->focused_time ? (float)$activityData->focused_time : 0,
            'unfocused_time' => $activityData && $activityData->unfocused_time ? (float)$activityData->unfocused_time : 0,
        ];

        // Attendance data
        $sql = "SELECT DATE(FROM_UNIXTIME(a.date)) as attendance_date, a.ispresent, COUNT(*) as count
                FROM {local_scholarwatch_attendance} a
                JOIN {local_scholarwatch_session} s ON a.sessionid = s.id
                WHERE s.courseid = :courseid
                GROUP BY DATE(FROM_UNIXTIME(a.date)), a.ispresent";
        $attendance_records = $DB->get_records_sql($sql, ['courseid' => $courseID]);
        
        $attendance = [];
        foreach ($attendance_records as $record) {
            $date = $record->attendance_date;
            if (!isset($attendance[$date])) {
                $attendance[$date] = ['present' => 0, 'absent' => 0];
            }
            if ($record->ispresent == 1) {
                $attendance[$date]['present'] += (int)$record->count;
            } else {
                $attendance[$date]['absent'] += (int)$record->count;
            }
        }

        // Quiz data (scores by quiz)
        $sql = "SELECT q.id as quiz_id, qq.iscorrect
                FROM {local_scholarwatch_quizquestion} qq
                JOIN {local_scholarwatch_quiz} q ON qq.quizid = q.id
                JOIN {local_scholarwatch_session} s ON q.sessionid = s.id
                WHERE s.courseid = :courseid";
        $quiz_records = $DB->get_records_sql($sql, ['courseid' => $courseID]);
        
        $quizScores = [];
        foreach ($quiz_records as $record) {
            $qId = $record->quiz_id;
            if (!isset($quizScores[$qId])) {
                $quizScores[$qId] = [];
            }
            // Generate realistic scores based on correctness
            if ($record->iscorrect == 1) {
                $quizScores[$qId][] = rand(70, 100);
            } else {
                $quizScores[$qId][] = rand(30, 69);
            }
        }

        // Slides data (average focus per slide)
        $sql = "SELECT sl.slidenumber, AVG(sl.focusduration) as avg_focus
                FROM {local_scholarwatch_slide} sl
                JOIN {local_scholarwatch_lecture} l ON sl.lectureid = l.id
                WHERE l.courseid = :courseid
                GROUP BY sl.slidenumber
                ORDER BY sl.slidenumber";
        $slide_records = $DB->get_records_sql($sql, ['courseid' => $courseID]);
        
        $slides = [];
        foreach ($slide_records as $record) {
            $slides[] = (float)$record->avg_focus;
        }

        // Lecture engagement over time (sum of FocusTime by date)
        $sql = "SELECT DATE(FROM_UNIXTIME(a.timestamp)) as day, SUM(a.focustime) as total_focus
                FROM {local_scholarwatch_activity} a
                JOIN {local_scholarwatch_session} s ON a.sessionid = s.id
                WHERE s.courseid = :courseid
                GROUP BY DATE(FROM_UNIXTIME(a.timestamp))
                ORDER BY day";
        $engagement_records = $DB->get_records_sql($sql, ['courseid' => $courseID]);
        
        $lectureEngagement = [];
        foreach ($engagement_records as $record) {
            $lectureEngagement[] = [
                'date' => $record->day,
                'time' => (float)$record->total_focus
            ];
        }

        $response['courses'][] = [
            'CourseID' => $courseID,
            'Name' => $course->name,
            'total_students' => $total_students,
            'total_lectures' => $total_lectures,
            'invalidation_count' => $invalidation_count,
            'emotions' => $emotions,
            'attention' => $attention,
            'attendance' => $attendance,
            'quiz_data' => $quizScores,
            'slides' => $slides,
            'lectureEngagement' => $lectureEngagement
        ];
    }

    echo json_encode($response);
    
} catch (Exception $e) {
    echo json_encode([
        "error" => $e->getMessage(),
        "line" => $e->getLine(),
        "file" => $e->getFile()
    ]);
}