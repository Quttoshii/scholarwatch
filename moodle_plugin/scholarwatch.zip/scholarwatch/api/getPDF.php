<?php
require_once(__DIR__ . '/../../../config.php');
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:3000");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: GET, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    http_response_code(200);
    exit;
}

header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Validate and sanitize filename
$filename = required_param('file', PARAM_FILE);
$filename = basename($filename); // prevent path traversal

// Full path in Moodle's dataroot
$filepath = $CFG->dataroot . '/local_scholarwatch/lectures/' . $filename;

// Serve the file if it exists
if (!file_exists($filepath)) {
    http_response_code(404);
    echo "File not found.";
    exit;
}

header('Content-Disposition: inline; filename="' . $filename . '"');
header('Content-Length: ' . filesize($filepath));
readfile($filepath);
exit;
