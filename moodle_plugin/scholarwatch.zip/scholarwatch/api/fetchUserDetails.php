<?php
// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:3000");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    http_response_code(200);
    exit;
}

// Actual CORS headers for main request
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Moodle bootstrap
require_once(__DIR__ . '/../../../config.php');
require_login();

// Global Moodle DB and user
global $DB;

// Get user ID from GET params
$userid = optional_param('userID', 0, PARAM_INT);

if (!$userid) {
    echo json_encode(["error" => "No user ID provided"]);
    exit;
}

try {
    // Get user data from Moodle's core user table
    $user = $DB->get_record('user', ['id' => $userid], 'id, firstname, lastname, email, suspended, country, phone1');

    if ($user) {
        echo json_encode($user);
    } else {
        echo json_encode(["error" => "User not found"]);
    }
} catch (Exception $e) {
    echo json_encode(["error" => "Database error: " . $e->getMessage()]);
}
