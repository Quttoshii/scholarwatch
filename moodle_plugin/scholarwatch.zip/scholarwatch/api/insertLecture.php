<?php
// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:3000");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    http_response_code(200);
    exit;
}

header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");


require_once(__DIR__ . '/../../../config.php');
require_login();


if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header("Content-Type: application/json");

global $DB, $USER, $CFG;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_FILES['lecture_file']) && isset($_POST['num_pages']) && isset($_POST['courseID'])) {
        $file = $_FILES['lecture_file'];
        $numPages = intval($_POST['num_pages']);
        $courseID = intval($_POST['courseID']);
        $sessionID = $_POST['sessionID'] ?? 1;

        // Validate course
        $course = $DB->get_record('local_scholarwatch_course', ['id' => $courseID]);
        if (!$course) {
            echo json_encode(["success" => false, "message" => "Invalid course"]);
            exit;
        }

        // Prepare storage path
        $lectureDir = $CFG->dataroot . '/local_scholarwatch/lectures/';
        if (!file_exists($lectureDir)) {
            mkdir($lectureDir, 0777, true);
        }

        $safeFilename = clean_filename($file['name']);
        $filepath = $lectureDir . $safeFilename;

        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            try {
                $record = new stdClass();
                $record->sessionid = $sessionID;
                $record->courseid = $courseID;
                $record->lecturename = pathinfo($safeFilename, PATHINFO_FILENAME);
                $record->directorypath = '/local_scholarwatch/lectures/' . $safeFilename;
                $record->slidecount = $numPages;
                $record->starttimestamp = time();

                $DB->insert_record('local_scholarwatch_lecture', $record);

                echo json_encode(["success" => true, "message" => "Lecture uploaded successfully"]);
            } catch (Exception $e) {
                echo json_encode(["success" => false, "error" => $e->getMessage()]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "Failed to move uploaded file"]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Invalid input"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
}
