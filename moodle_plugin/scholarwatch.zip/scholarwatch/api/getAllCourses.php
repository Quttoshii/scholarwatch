<?php
// Moodle plugin-compatible version for fetching all courses

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:3000");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    http_response_code(200);
    exit;
}

// Set CORS headers for all requests
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

require_once(__DIR__ . '/../../../config.php');
require_login();

header("Content-Type: application/json");

global $DB;

try {
    // ✅ FIXED: Removed comma at the end of SELECT
    $sql = "
        SELECT 
            c.id AS courseid, 
            c.name AS coursename
        FROM {local_scholarwatch_course} c
    ";

    // ✅ FIXED: Removed unused parameter binding
    $courses = $DB->get_records_sql($sql);

    $formatted = array_map(function($c) {
        return [
            'CourseID'   => $c->courseid,
            'CourseName' => $c->coursename
        ];
    }, array_values($courses));

    echo json_encode([
        'success' => true,
        'courses' => $formatted
    ]);

} catch (Exception $e) {
    error_log("Error in getTeacherCourses.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching courses: ' . $e->getMessage()
    ]);
}
