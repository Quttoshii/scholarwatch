<?php
require_once(__DIR__ . '/../../../config.php');
require_login();

$filename = required_param('file', PARAM_FILE); // e.g. genai.pdf

$filepath = $CFG->dataroot . '/local_scholarwatch/lectures/' . basename($filename);

if (!file_exists($filepath)) {
    http_response_code(404);
    echo "File not found.";
    exit;
}

header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="' . basename($filename) . '"');
readfile($filepath);
exit;
