<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

defined('MOODLE_INTERNAL') || die();

/**
 * Post installation procedure for local_scholarwatch
 */
function xmldb_local_scholarwatch_install() {
    global $DB;

    // Insert dummy users
    $users = [
        [
            'name' => 'Ahmed Ali',
            'email' => 'ahmed.ali@gmail.com',
            'password' => 'default_1',
            'usertype' => 'Teacher',
            'threshold' => 0.75,
            'status' => 'Active',
            'nationality' => 'Pakistani',
            'gender' => 'Male',
            'dob' => strtotime('1985-01-01'),
            'mobilenumber' => '+92 300 1234567'
        ],
        [
            'name' => 'Fatima Khan',
            'email' => 'fatima.khan@gmail.com',
            'password' => 'default_2',
            'usertype' => 'Teacher',
            'threshold' => 0.8,
            'status' => 'Active',
            'nationality' => 'Pakistani',
            'gender' => 'Female',
            'dob' => strtotime('1987-03-15'),
            'mobilenumber' => '+92 300 2345678'
        ],
        [
            'name' => 'Hassan Raza',
            'email' => 'hassan.raza@gmail.com',
            'password' => 'default_3',
            'usertype' => 'Student',
            'threshold' => null,
            'status' => 'Active',
            'nationality' => 'Pakistani',
            'gender' => 'Male',
            'dob' => strtotime('2000-05-10'),
            'mobilenumber' => '+92 300 3456789'
        ],
        [
            'name' => 'Ayesha Malik',
            'email' => 'ayesha.malik@gmail.com',
            'password' => 'default_4',
            'usertype' => 'Student',
            'threshold' => null,
            'status' => 'Active',
            'nationality' => 'Pakistani',
            'gender' => 'Female',
            'dob' => strtotime('1999-08-22'),
            'mobilenumber' => '+92 300 4567890'
        ],
        [
            'name' => 'Zainab Tariq',
            'email' => 'zainab.tariq@gmail.com',
            'password' => 'default_5',
            'usertype' => 'Student',
            'threshold' => null,
            'status' => 'Active',
            'nationality' => 'Pakistani',
            'gender' => 'Female',
            'dob' => strtotime('2001-12-03'),
            'mobilenumber' => '+92 300 5678901'
        ]
    ];

    // Insert users and store their IDs
    $user_ids = [];
    foreach ($users as $user) {
        $user_id = $DB->insert_record('local_scholarwatch_user', (object)$user);
        $user_ids[] = $user_id;
    }

    // Insert dummy courses
    $courses = [
        [
            'name' => 'Computer Science',
            'teacherid' => $user_ids[0] // Ahmed Ali
        ],
        [
            'name' => 'Mathematics',
            'teacherid' => $user_ids[1] // Fatima Khan
        ]
    ];

    $course_ids = [];
    foreach ($courses as $course) {
        $course_id = $DB->insert_record('local_scholarwatch_course', (object)$course);
        $course_ids[] = $course_id;
    }

    // Insert dummy sessions
    $sessions = [
        [
            'sessiontype' => 'Lecture',
            'courseid' => $course_ids[0],
            'userid' => $user_ids[0],
            'sessiondate' => strtotime('2024-01-15'),
            'starttimestamp' => strtotime('2024-01-15 09:00:00'),
            'endtimestamp' => strtotime('2024-01-15 10:30:00')
        ],
        [
            'sessiontype' => 'Lecture',
            'courseid' => $course_ids[1],
            'userid' => $user_ids[1],
            'sessiondate' => strtotime('2024-01-16'),
            'starttimestamp' => strtotime('2024-01-16 10:00:00'),
            'endtimestamp' => strtotime('2024-01-16 11:00:00')
        ],
        [
            'sessiontype' => 'Quiz',
            'courseid' => $course_ids[0],
            'userid' => $user_ids[0],
            'sessiondate' => strtotime('2024-01-17'),
            'starttimestamp' => strtotime('2024-01-17 11:00:00'),
            'endtimestamp' => strtotime('2024-01-17 11:30:00')
        ]
    ];

    $session_ids = [];
    foreach ($sessions as $session) {
        $session_id = $DB->insert_record('local_scholarwatch_session', (object)$session);
        $session_ids[] = $session_id;
    }

    // Insert dummy lectures
    $lectures = [
        [
            'sessionid' => $session_ids[0],
            'courseid' => $course_ids[0],
            'lecturename' => 'Introduction to Programming',
            'directorypath' => '/lectures/programming_intro.pdf',
            'slidecount' => 10,
            'starttimestamp' => strtotime('2024-01-15 09:00:00'),
            'endtimestamp' => strtotime('2024-01-15 10:30:00')
        ],
        [
            'sessionid' => $session_ids[1],
            'courseid' => $course_ids[1],
            'lecturename' => 'Algebra Basics',
            'directorypath' => '/lectures/algebra_basics.pdf',
            'slidecount' => 8,
            'starttimestamp' => strtotime('2024-01-16 10:00:00'),
            'endtimestamp' => strtotime('2024-01-16 11:00:00')
        ]
    ];

    $lecture_ids = [];
    foreach ($lectures as $lecture) {
        $lecture_id = $DB->insert_record('local_scholarwatch_lecture', (object)$lecture);
        $lecture_ids[] = $lecture_id;
    }

    // Insert dummy slides
    $slides = [
        [
            'lectureid' => $lecture_ids[0],
            'slidenumber' => 1,
            'focusduration' => 150.5
        ],
        [
            'lectureid' => $lecture_ids[0],
            'slidenumber' => 2,
            'focusduration' => 200.8
        ],
        [
            'lectureid' => $lecture_ids[1],
            'slidenumber' => 1,
            'focusduration' => 180.3
        ],
        [
            'lectureid' => $lecture_ids[1],
            'slidenumber' => 2,
            'focusduration' => 140.2
        ]
    ];

    $slide_ids = [];
    foreach ($slides as $slide) {
        $slide_id = $DB->insert_record('local_scholarwatch_slide', (object)$slide);
        $slide_ids[] = $slide_id;
    }

    // Insert dummy quizzes
    $quizzes = [
        [
            'sessionid' => $session_ids[2],
            'lectureid' => $lecture_ids[0],
            'userid' => $user_ids[2], // Hassan Raza
            'generateddate' => strtotime('2024-01-17 11:00:00'),
            'attemptcount' => 1,
            'invalidationcount' => 0,
            'invalidationreason' => null,
            'allotedtime' => 30,
            'contentid' => null,
            'is_invalid' => 0
        ],
        [
            'sessionid' => $session_ids[2],
            'lectureid' => $lecture_ids[0],
            'userid' => $user_ids[3], // Ayesha Malik
            'generateddate' => strtotime('2024-01-17 11:05:00'),
            'attemptcount' => 2,
            'invalidationcount' => 1,
            'invalidationreason' => 'Tab Switch',
            'allotedtime' => 30,
            'contentid' => null,
            'is_invalid' => 1
        ]
    ];

    $quiz_ids = [];
    foreach ($quizzes as $quiz) {
        $quiz_id = $DB->insert_record('local_scholarwatch_quiz', (object)$quiz);
        $quiz_ids[] = $quiz_id;
    }

    // Insert dummy quiz questions
    $quiz_questions = [
        [
            'quizid' => $quiz_ids[0],
            'questiontext' => 'What is a variable in programming?',
            'correctanswer' => 'Storage of data',
            'studentanswer' => 'Storage of data',
            'iscorrect' => 1
        ],
        [
            'quizid' => $quiz_ids[1],
            'questiontext' => 'What is 2 + 2?',
            'correctanswer' => '4',
            'studentanswer' => '3',
            'iscorrect' => 0
        ]
    ];

    foreach ($quiz_questions as $question) {
        $DB->insert_record('local_scholarwatch_quizquestion', (object)$question);
    }

    // Insert dummy attendance records
    $attendance_records = [
        [
            'userid' => $user_ids[2], // Hassan Raza
            'sessionid' => $session_ids[0],
            'date' => strtotime('2024-01-15'),
            'ispresent' => 1,
            'courseid' => $course_ids[0]
        ],
        [
            'userid' => $user_ids[3], // Ayesha Malik
            'sessionid' => $session_ids[0],
            'date' => strtotime('2024-01-15'),
            'ispresent' => 1,
            'courseid' => $course_ids[0]
        ],
        [
            'userid' => $user_ids[4], // Zainab Tariq
            'sessionid' => $session_ids[1],
            'date' => strtotime('2024-01-16'),
            'ispresent' => 1,
            'courseid' => $course_ids[1]
        ]
    ];

    foreach ($attendance_records as $attendance) {
        $DB->insert_record('local_scholarwatch_attendance', (object)$attendance);
    }

    // Insert dummy activity records
    $activity_records = [
        [
            'userid' => $user_ids[2], // Hassan Raza
            'sessionid' => $session_ids[0],
            'slideid' => $slide_ids[0],
            'focustime' => 300.0,
            'unfocustime' => 50.0,
            'slouchingtime' => 20.0,
            'attentivetime' => 280.0,
            'lookinglefttime' => 10.0,
            'lookingrighttime' => 15.0,
            'phoneusagetime' => 5.0,
            'drowsytime' => 30.0,
            'awaketime' => 270.0,
            'timestamp' => strtotime('2024-01-15 09:15:00')
        ],
        [
            'userid' => $user_ids[3], // Ayesha Malik
            'sessionid' => $session_ids[0],
            'slideid' => $slide_ids[1],
            'focustime' => 250.0,
            'unfocustime' => 60.0,
            'slouchingtime' => 30.0,
            'attentivetime' => 220.0,
            'lookinglefttime' => 15.0,
            'lookingrighttime' => 10.0,
            'phoneusagetime' => 10.0,
            'drowsytime' => 40.0,
            'awaketime' => 210.0,
            'timestamp' => strtotime('2024-01-15 09:30:00')
        ]
    ];

    foreach ($activity_records as $activity) {
        $DB->insert_record('local_scholarwatch_activity', (object)$activity);
    }

    // Insert dummy analytics records
    $analytics_records = [
        [
            'userid' => $user_ids[2], // Hassan Raza
            'sessionid' => $session_ids[0],
            'weaktopics' => 'Loops, Functions',
            'averagefocus' => 250.5,
            'performancescore' => 78.0,
            'improvementsuggestions' => 'Practice more on loops and try solving function problems.'
        ],
        [
            'userid' => $user_ids[3], // Ayesha Malik
            'sessionid' => $session_ids[0],
            'weaktopics' => 'Algebra Basics',
            'averagefocus' => 220.0,
            'performancescore' => 85.0,
            'improvementsuggestions' => 'Improve algebraic equation solving speed.'
        ]
    ];

    foreach ($analytics_records as $analytic) {
        $DB->insert_record('local_scholarwatch_analytics', (object)$analytic);
    }

    // Insert dummy posture detection records
    $posture_records = [
        [
            'sessionid' => $session_ids[0],
            'goodposturetime' => 6.9741,
            'slouchingtime' => 0.8508,
            'lookinglefttime' => 0.4816,
            'lookingrighttime' => 0.8176,
            'usingphonetime' => 0.0,
            'createdat' => strtotime('2024-01-15 09:30:00')
        ]
    ];

    foreach ($posture_records as $posture) {
        $DB->insert_record('local_scholarwatch_posturedetection', (object)$posture);
    }

    // Insert dummy attention records
    $attention_records = [
        [
            'moduleid' => 1,
            'awaketime' => 1.5,
            'drowsytime' => 0.5,
            'focusedtime' => 2.0,
            'unfocusedtime' => 0.5
        ],
        [
            'moduleid' => 2,
            'awaketime' => 2.0,
            'drowsytime' => 0.4,
            'focusedtime' => 1.5,
            'unfocusedtime' => 0.3
        ],
        [
            'moduleid' => 3,
            'awaketime' => 1.2,
            'drowsytime' => 0.8,
            'focusedtime' => 1.8,
            'unfocusedtime' => 0.7
        ]
    ];

    foreach ($attention_records as $attention) {
        $DB->insert_record('local_scholarwatch_attention', (object)$attention);
    }

    // Insert Knowledge Graphs
    $knowledgegraphs = [
        [
            'courseid' => $course_ids[0],
            'name' => 'Computer Science Knowledge Graph',
            'description' => 'Complete knowledge graph for Computer Science course',
            'createdat' => time()
        ],
        [
            'courseid' => $course_ids[1],
            'name' => 'Mathematics Knowledge Graph',
            'description' => 'Complete knowledge graph for Mathematics course',
            'createdat' => time()
        ]
    ];

    $graph_ids = [];
    foreach ($knowledgegraphs as $graph) {
        $graph_ids[] = $DB->insert_record('local_scholarwatch_knowledgegraph', (object)$graph);
    }

    // Insert Knowledge Nodes
    $nodes = [
        // Computer Science Graph
        ['graphid' => $graph_ids[0], 'lectureid' => $lecture_ids[0], 'name' => 'Introduction to Programming', 'type' => 'LECTURE', 'description' => 'Basic programming concepts and syntax', 'positionx' => 100, 'positiony' => 100, 'status' => 'COMPLETED'],
        ['graphid' => $graph_ids[0], 'lectureid' => null, 'name' => 'Variables and Data Types', 'type' => 'LECTURE', 'description' => 'Understanding different data types and variables', 'positionx' => 250, 'positiony' => 100, 'status' => 'UNLOCKED'],
        ['graphid' => $graph_ids[0], 'lectureid' => null, 'name' => 'Control Structures', 'type' => 'LECTURE', 'description' => 'Loops and conditional statements', 'positionx' => 400, 'positiony' => 100, 'status' => 'LOCKED'],

        // Mathematics Graph
        ['graphid' => $graph_ids[1], 'lectureid' => $lecture_ids[1], 'name' => 'Basic Algebra', 'type' => 'LECTURE', 'description' => 'Introduction to algebraic expressions', 'positionx' => 100, 'positiony' => 100, 'status' => 'COMPLETED'],
        ['graphid' => $graph_ids[1], 'lectureid' => null, 'name' => 'Linear Equations', 'type' => 'LECTURE', 'description' => 'Solving linear equations', 'positionx' => 250, 'positiony' => 100, 'status' => 'UNLOCKED'],
        ['graphid' => $graph_ids[1], 'lectureid' => null, 'name' => 'Quadratic Equations', 'type' => 'LECTURE', 'description' => 'Solving quadratic equations', 'positionx' => 400, 'positiony' => 100, 'status' => 'LOCKED']
    ];

    $node_ids = [];
    foreach ($nodes as $node) {
        $node_ids[] = $DB->insert_record('local_scholarwatch_knowledgenode', (object)$node);
    }

    // Insert Knowledge Edges
    $edges = [
        ['graphid' => $graph_ids[0], 'sourcenodeid' => $node_ids[0], 'targetnodeid' => $node_ids[1], 'type' => 'PREREQUISITE', 'weight' => 1.0],
        ['graphid' => $graph_ids[0], 'sourcenodeid' => $node_ids[1], 'targetnodeid' => $node_ids[2], 'type' => 'PREREQUISITE', 'weight' => 1.0],

        ['graphid' => $graph_ids[1], 'sourcenodeid' => $node_ids[3], 'targetnodeid' => $node_ids[4], 'type' => 'PREREQUISITE', 'weight' => 1.0],
        ['graphid' => $graph_ids[1], 'sourcenodeid' => $node_ids[4], 'targetnodeid' => $node_ids[5], 'type' => 'PREREQUISITE', 'weight' => 1.0],
    ];

    foreach ($edges as $edge) {
        $DB->insert_record('local_scholarwatch_knowledgeedge', (object)$edge);
    }

    // Insert Student Lecture Status
    $student_ids = [$user_ids[2], $user_ids[3]]; // Hassan, Ayesha
    foreach ($student_ids as $studentid) {
        foreach ($node_ids as $i => $nodeid) {
            $status = ($i % 3 === 0) ? 'UNLOCKED' : 'LOCKED'; // First lecture node in each graph is UNLOCKED
            $DB->insert_record('local_scholarwatch_studentlecturestatus', (object)[
                'studentid' => $studentid,
                'nodeid' => $nodeid,
                'status' => $status
            ]);
        }
    }


    return true;
}