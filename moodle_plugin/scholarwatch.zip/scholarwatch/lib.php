<?php
defined('MOODLE_INTERNAL') || die();

function local_scholarwatch_extend_navigation(global_navigation $nav) {
    global $CFG, $USER;

    $url = new moodle_url('/local/scholarwatch/index.php');
    $nav->add(get_string('scholarwatch', 'local_scholarwatch'), $url, navigation_node::TYPE_CUSTOM, null, 'scholarwatch');
}
